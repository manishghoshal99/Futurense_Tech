# Important Note

**Please note that the view at GitHub is nothing more than a preview meant for developers. It doesn't support a lot of features of notebooks, such as interactive Plotly plots, and has faulty rendering in a number of ways.**

If you want to see the notebook along with the interactive graphs, **download the .ipynb file to your local machine and run it in a Jupyter environment**. This will enable you to experience the full functionality of the notebook, including the interactive features.

Thank you for your understanding.
